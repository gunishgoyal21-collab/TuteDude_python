#1) task 1

number = int(input("Enter a number: "))
print(f"your number is {number}")

print("it's an even number") if number % 2 == 0 else print("it's an odd number")

#2) task 2

sum = 0
for i in range(1, 51):
    sum += i
print(f"Sum of numbers from 1 to 50 is: {sum}")