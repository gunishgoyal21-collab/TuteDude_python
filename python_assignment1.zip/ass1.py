#1)
print("Enter two numbers to perform arithmetic operations:")
a = int(input("enter first number: "))
b = int(input("enter second number: "))
sum = a + b
print("The sum of", a, "and", b, "is", sum)
subtraction = a - b
print("The subtraction of", a, "and", b, "is", subtraction)
multiplication = a * b
print("The multiplication of", a, "and", b, "is", multiplication)
division = a / b
print("The division of", a, "and", b, "is", division)


#2)
f_name = input("Enter your first name: ")
l_name = input("Enter your last name: ")
full_name = f_name + " " + l_name
print("Hello", full_name,"! Welcome to Python program.")

